import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(DisasterManagementApp());
}

class DisasterManagementApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Disaster Management',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Database offlineDb;
  FlutterLocalNotificationsPlugin localNotifications = FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    _initOfflineDatabase();
    _initNotifications();
  }

  void _initOfflineDatabase() async {
    String path = join(await getDatabasesPath(), 'disaster_app.db');
    offlineDb = await openDatabase(
      path,
      onCreate: (db, version) {
        return db.execute(
          "CREATE TABLE resources(id INTEGER PRIMARY KEY, title TEXT, description TEXT)"
        );
      },
      version: 1,
    );
    print("Offline database initialized.");
  }

  void _initNotifications() {
    var androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    var initSettings = InitializationSettings(android: androidInit);

    localNotifications.initialize(initSettings, onSelectNotification: (String? payload) async {
      if (payload != null) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ResourceDetailsScreen(payload: payload)),
        );
      }
    });
  }

  Future<void> _showNotification(String title, String body) async {
    var androidDetails = AndroidNotificationDetails(
      'channelId',
      'channelName',
      importance: Importance.max,
      priority: Priority.high,
    );
    var details = NotificationDetails(android: androidDetails);
    await localNotifications.show(0, title, body, details);
  }

  Future<void> _addOfflineResource(String title, String description) async {
    await offlineDb.insert(
      'resources',
      {'title': title, 'description': description},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    print("Resource added to offline database.");
  }

  Widget _buildEmergencyContacts() {
    return Column(
      children: [
        ListTile(
          title: Text("Police"),
          subtitle: Text("100"),
          trailing: IconButton(
            icon: Icon(Icons.phone),
            onPressed: () {
              // Add functionality to call emergency number
            },
          ),
        ),
        ListTile(
          title: Text("Fire Brigade"),
          subtitle: Text("101"),
          trailing: IconButton(
            icon: Icon(Icons.phone),
            onPressed: () {
              // Add functionality to call emergency number
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Smart Disaster Management'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Emergency Resources',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              _buildEmergencyContacts(),
              SizedBox(height: 20),
              Text(
                'Disaster Guides (Offline)',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  await _addOfflineResource('Flood Safety Guide', 'Steps to stay safe during floods.');
                  _showNotification('New Guide Added', 'Flood Safety Guide is now available offline.');
                },
                child: Text('Add Offline Guide'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ResourceDetailsScreen extends StatelessWidget {
  final String payload;

  ResourceDetailsScreen({required this.payload});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Resource Details'),
      ),
      body: Center(
        child: Text(payload),
      ),
    );
  }
}
