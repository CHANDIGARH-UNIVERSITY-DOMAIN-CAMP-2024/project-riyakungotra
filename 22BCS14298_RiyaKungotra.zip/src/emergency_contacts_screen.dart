import 'package:flutter/material.dart';

class EmergencyContactsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Emergency Contacts'),
      ),
      body: ListView(
        children: <Widget>[
          ListTile(
            title: Text('Police'),
            subtitle: Text('100'),
          ),
          ListTile(
            title: Text('Ambulance'),
            subtitle: Text('102'),
          ),
          ListTile(
            title: Text('Fire Brigade'),
            subtitle: Text('101'),
          ),
        ],
      ),
    );
  }
}