import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class SQLiteService {
  static Database _database;

  static Future<Database> get database async {
    if (_database != null) return _database;
    _database = await _initDatabase();
    return _database;
  }

  static Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'disaster_management.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) {
        return db.execute(
          "CREATE TABLE disaster_info(id INTEGER PRIMARY KEY, title TEXT, description TEXT)",
        );
      },
    );
  }

  static Future<void> saveDisasterInfo(List<dynamic> data) async {
    final db = await database;
    await db.delete('disaster_info');
    for (var item in data) {
      await db.insert('disaster_info', {
        'id': item['id'],
        'title': item['title'],
        'description': item['description'],
      });
    }
  }

  static Future<List<dynamic>> getDisasterInfo() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('disaster_info');
    return List.generate(maps.length, (i) {
      return {
        'id': maps[i]['id'],
        'title': maps[i]['title'],
        'description': maps[i]['description'],
      };
    });
  }
}