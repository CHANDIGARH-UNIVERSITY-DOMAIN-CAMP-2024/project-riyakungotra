import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sqlite_service.dart';

class DisasterInfoScreen extends StatefulWidget {
  @override
  _DisasterInfoScreenState createState() => _DisasterInfoScreenState();
}

class _DisasterInfoScreenState extends State<DisasterInfoScreen> {
  List<dynamic> disasterInfo = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      // Fetch data from REST API
      final data = await ApiService.fetchDisasterInfo();
      setState(() {
        disasterInfo = data;
      });

      // Save data to SQLite for offline access
      await SQLiteService.saveDisasterInfo(data);
    } catch (e) {
      // Load data from SQLite if API call fails
      final data = await SQLiteService.getDisasterInfo();
      setState(() {
        disasterInfo = data;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Disaster Information'),
      ),
      body: ListView.builder(
        itemCount: disasterInfo.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(disasterInfo[index]['title']),
            subtitle: Text(disasterInfo[index]['description']),
          );
        },
      ),
    );
  }
}